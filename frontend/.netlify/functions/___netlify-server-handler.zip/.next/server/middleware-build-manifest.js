globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/dbmA2Z97o-bapv_8jtcok/_buildManifest.js",
    "static/dbmA2Z97o-bapv_8jtcok/_ssgManifest.js",
    "static/dbmA2Z97o-bapv_8jtcok/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/08ttfj81-47mu.js",
    "static/chunks/213zvx-x_gk21.js",
    "static/chunks/turbopack-2yx5tmgpd3t6c.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
